import './App.css';
import PokemonApi from './views/PokemonApi';

function App() {
  return (
    <div className="Container">
      <PokemonApi/>
    </div>
  );
}

export default App;