import React from 'react'

export const ErrorPage = () => {

    const ErrorPage = () =>{

        
        return{}}


  return (
    <div>


    </div>
  )
}