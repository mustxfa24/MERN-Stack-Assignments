import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div class = "center">
      <h1> Hello Dojo! </h1>
      <h2> Things I need to do: </h2>
      <ul>
        <li> Learn React </li>
        <li> Upgrade my web portfolio </li>
        <li> Complete 2-4 website commissions  </li>
        <li> Read at least 1 book a month </li>
        <li> Play video games </li>
        <li> Learn something new </li>
      </ul>
    </div>
  );
}

export default App;
