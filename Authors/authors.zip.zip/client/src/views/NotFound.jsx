export const NotFound = (props) => {
    return 'Page Not Found.';
};

export default NotFound;